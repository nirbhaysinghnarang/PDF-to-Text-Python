# pdf_to_text

## Usage 
  * import pdf_to_txt
  * Create a pdf_to_txt object
  * Pass in file name without extension, target name without extension, and path.
  * Call object.convert_to_txt()
  * Done
